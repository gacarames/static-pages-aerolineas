$('.date').datepicker({
	orientation:'bottom left'
});





$('#inputOrigin').typeahead({
    local: ['alpha', 'allpha2', 'alpha3', 'bravo', 'charlie', 'delta', 'epsilon', 'gamma', 'zulu']
});
$('#inputOrigin2').typeahead({
    local: ['alpha', 'allpha2', 'alpha3', 'bravo', 'charlie', 'delta', 'epsilon', 'gamma', 'zulu']
});

$('#inputDestination').typeahead({
    local: ['alpha', 'allpha2', 'alpha3', 'bravo', 'charlie', 'delta', 'epsilon', 'gamma', 'zulu']
});
$('#inputDestination2').typeahead({
    local: ['alpha', 'allpha2', 'alpha3', 'bravo', 'charlie', 'delta', 'epsilon', 'gamma', 'zulu']
});

$('#inputOriginSchedules').typeahead({
    local: ['alpha', 'allpha2', 'alpha3', 'bravo', 'charlie', 'delta', 'epsilon', 'gamma', 'zulu']
});

$('#inputDestinationSchedules').typeahead({
    local: ['alpha', 'allpha2', 'alpha3', 'bravo', 'charlie', 'delta', 'epsilon', 'gamma', 'zulu']
});

$('.tt-query').css('background-color', '#fff');

